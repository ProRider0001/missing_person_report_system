-- Run this once:
-- psql -U postgres -d missing_person_db -f database/schema.sql

DROP TABLE IF EXISTS enquiries;
DROP TABLE IF EXISTS cases;
DROP TABLE IF EXISTS users;

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── USERS ──────────────────────────────────────────────────
CREATE TABLE users (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(150) UNIQUE NOT NULL,
  phone         VARCHAR(15)  NOT NULL,
  password      VARCHAR(255) NOT NULL,
  role          VARCHAR(10)  NOT NULL DEFAULT 'user'
                  CHECK (role IN ('user','police')),
  -- police-only fields
  badge_number  VARCHAR(60),
  station_name  VARCHAR(150),
  station_area  VARCHAR(150),
  created_at    TIMESTAMP DEFAULT NOW()
);

-- ── MISSING PERSON CASES ───────────────────────────────────
CREATE TABLE cases (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- who filed the report
  reported_by           INT REFERENCES users(id) ON DELETE SET NULL,
  reporter_name         VARCHAR(120) NOT NULL,
  reporter_phone        VARCHAR(15)  NOT NULL,
  reporter_email        VARCHAR(150),
  reporter_relation     VARCHAR(80)  NOT NULL,

  -- missing person
  mp_name               VARCHAR(120) NOT NULL,
  mp_age                INT          NOT NULL,
  mp_gender             VARCHAR(10)  NOT NULL CHECK (mp_gender IN ('Male','Female','Other')),
  mp_dob                DATE,
  mp_nationality        VARCHAR(80)  DEFAULT 'Indian',
  mp_height_cm          INT,
  mp_weight_kg          INT,
  mp_hair               VARCHAR(80),
  mp_eyes               VARCHAR(50),
  mp_marks              TEXT,

  -- last seen
  last_seen_date        DATE         NOT NULL,
  last_seen_time        TIME,
  last_seen_location    TEXT         NOT NULL,
  clothing              TEXT         NOT NULL,
  clothing_color        VARCHAR(120),
  photo_url             TEXT,

  -- FIR / police
  fir_number            VARCHAR(80),
  police_station        VARCHAR(150),
  police_area           VARCHAR(150),

  -- case status
  status                VARCHAR(25)  DEFAULT 'active'
                          CHECK (status IN ('active','found','closed')),
  case_number           VARCHAR(60)  UNIQUE,
  current_location      TEXT,
  found_date            DATE,
  found_notes           TEXT,

  created_at            TIMESTAMP DEFAULT NOW(),
  updated_at            TIMESTAMP DEFAULT NOW()
);

-- auto case number
CREATE OR REPLACE FUNCTION gen_case_number()
RETURNS TRIGGER AS $$
BEGIN
  NEW.case_number := 'MPS-' || TO_CHAR(NOW(),'YYYY') || '-'
                     || LPAD((FLOOR(RANDOM()*99999)+1)::TEXT, 5,'0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_case_number
  BEFORE INSERT ON cases
  FOR EACH ROW WHEN (NEW.case_number IS NULL)
  EXECUTE FUNCTION gen_case_number();

-- auto updated_at
CREATE OR REPLACE FUNCTION touch_updated()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_updated
  BEFORE UPDATE ON cases
  FOR EACH ROW EXECUTE FUNCTION touch_updated();

-- ── ENQUIRIES ──────────────────────────────────────────────
CREATE TABLE enquiries (
  id                  SERIAL PRIMARY KEY,
  asked_by            INT REFERENCES users(id) ON DELETE SET NULL,
  person_name         VARCHAR(120),
  approx_age          INT,
  gender              VARCHAR(10),
  last_seen_date      DATE         NOT NULL,
  last_seen_place     TEXT         NOT NULL,
  clothing            TEXT         NOT NULL,
  extra_desc          TEXT,
  -- police verification
  officer_name        VARCHAR(120) NOT NULL,
  officer_badge       VARCHAR(60)  NOT NULL,
  officer_station     VARCHAR(150) NOT NULL,
  fir_number          VARCHAR(80),
  -- match
  matched_case_id     UUID REFERENCES cases(id) ON DELETE SET NULL,
  created_at          TIMESTAMP DEFAULT NOW()
);
