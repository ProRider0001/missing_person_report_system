import pool from '../../../lib/db';
import { compare, sign } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required.' });

  try {
    const r = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
    if (!r.rows.length) return res.status(400).json({ error: 'No account found with this email.' });
    const user = r.rows[0];
    if (!await compare(password, user.password))
      return res.status(400).json({ error: 'Wrong password.' });

    return res.json({
      token: sign(user),
      user: { id: user.id, name: user.name, email: user.email, role: user.role,
              station_name: user.station_name, station_area: user.station_area }
    });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Server error.' });
  }
}
