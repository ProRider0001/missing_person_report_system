import pool from '../../../lib/db';
import { hash, sign } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { name, email, phone, password, role, badge_number, station_name, station_area } = req.body;

  if (!name || !email || !phone || !password)
    return res.status(400).json({ error: 'Name, email, phone and password are required.' });
  if (password.length < 6)
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  if (role === 'police' && (!badge_number || !station_name || !station_area))
    return res.status(400).json({ error: 'Badge number, station name and area are required for police.' });

  try {
    const dup = await pool.query('SELECT id FROM users WHERE email=$1', [email]);
    if (dup.rows.length) return res.status(400).json({ error: 'Email already registered.' });

    const pw = await hash(password);
    const r  = await pool.query(
      `INSERT INTO users (name,email,phone,password,role,badge_number,station_name,station_area)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id,name,email,role,station_name,station_area`,
      [name, email, phone, pw, role||'user', badge_number||null, station_name||null, station_area||null]
    );
    const user = r.rows[0];
    return res.status(201).json({ token: sign(user), user });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Server error.' });
  }
}
