import pool from '../../../lib/db';
import { auth } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).end();
  const user = auth(req, res); if (!user) return;
  if (user.role !== 'police') return res.status(403).json({ error: 'Police only.' });

  try {
    // get logged-in police user's station area
    const uRow = await pool.query('SELECT station_area, station_name FROM users WHERE id=$1', [user.id]);
    const { station_area, station_name } = uRow.rows[0];

    const total  = await pool.query("SELECT COUNT(*) FROM cases WHERE police_area ILIKE $1", [`%${station_area}%`]);
    const active = await pool.query("SELECT COUNT(*) FROM cases WHERE police_area ILIKE $1 AND status='active'", [`%${station_area}%`]);
    const found  = await pool.query("SELECT COUNT(*) FROM cases WHERE police_area ILIKE $1 AND status='found'", [`%${station_area}%`]);
    const closed = await pool.query("SELECT COUNT(*) FROM cases WHERE police_area ILIKE $1 AND status='closed'", [`%${station_area}%`]);

    const recent = await pool.query(
      `SELECT id, case_number, mp_name, mp_age, mp_gender,
              last_seen_date, last_seen_location, status, created_at
       FROM cases WHERE police_area ILIKE $1
       ORDER BY created_at DESC LIMIT 10`,
      [`%${station_area}%`]
    );

    return res.json({
      station_name,
      station_area,
      stats: {
        total:  parseInt(total.rows[0].count),
        active: parseInt(active.rows[0].count),
        found:  parseInt(found.rows[0].count),
        closed: parseInt(closed.rows[0].count),
      },
      recent_cases: recent.rows,
    });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Server error.' });
  }
}
