import pool from '../../../lib/db';
import { auth } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const user = auth(req, res); if (!user) return;

  const {
    reporter_name, reporter_phone, reporter_email, reporter_relation,
    mp_name, mp_age, mp_gender, mp_dob, mp_nationality,
    mp_height_cm, mp_weight_kg, mp_hair, mp_eyes, mp_marks,
    last_seen_date, last_seen_time, last_seen_location,
    clothing, clothing_color, photo_url,
    fir_number, police_station, police_area,
  } = req.body;

  if (!reporter_name || !reporter_phone || !reporter_relation)
    return res.status(400).json({ error: 'Reporter name, phone and relation are required.' });
  if (!mp_name || !mp_age || !mp_gender)
    return res.status(400).json({ error: 'Missing person name, age and gender are required.' });
  if (!last_seen_date || !last_seen_location || !clothing)
    return res.status(400).json({ error: 'Last seen date, location and clothing are required.' });

  try {
    const r = await pool.query(
      `INSERT INTO cases (
        reported_by, reporter_name, reporter_phone, reporter_email, reporter_relation,
        mp_name, mp_age, mp_gender, mp_dob, mp_nationality,
        mp_height_cm, mp_weight_kg, mp_hair, mp_eyes, mp_marks,
        last_seen_date, last_seen_time, last_seen_location,
        clothing, clothing_color, photo_url,
        fir_number, police_station, police_area
      ) VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
        $11,$12,$13,$14,$15,$16,$17,$18,
        $19,$20,$21,$22,$23,$24
      ) RETURNING *`,
      [
        user.id, reporter_name, reporter_phone, reporter_email||null, reporter_relation,
        mp_name, mp_age, mp_gender, mp_dob||null, mp_nationality||'Indian',
        mp_height_cm||null, mp_weight_kg||null, mp_hair||null, mp_eyes||null, mp_marks||null,
        last_seen_date, last_seen_time||null, last_seen_location,
        clothing, clothing_color||null, photo_url||null,
        fir_number||null, police_station||null, police_area||null,
      ]
    );
    return res.status(201).json({ data: r.rows[0] });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Server error.' });
  }
}
