import pool from '../../../lib/db';
import { auth } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const user = auth(req, res); if (!user) return;

  const { person_name, approx_age, gender,
          last_seen_date, last_seen_place, clothing, extra_desc } = req.body;

  if (!last_seen_date || !last_seen_place || !clothing)
    return res.status(400).json({ error: 'Last seen date, place and clothing are required.' });

  try {
    let matched = null;
    const conds = [], params = [];

    if (person_name?.trim()) {
      params.push('%' + person_name.toLowerCase() + '%');
      conds.push(`LOWER(mp_name) LIKE $${params.length}`);
    }
    if (last_seen_place?.trim()) {
      params.push('%' + last_seen_place.toLowerCase() + '%');
      conds.push(`LOWER(last_seen_location) LIKE $${params.length}`);
    }
    if (gender) {
      params.push(gender);
      conds.push(`mp_gender = $${params.length}`);
    }

    let q = "SELECT * FROM cases WHERE status='active'";
    if (conds.length) q += ' AND (' + conds.join(' OR ') + ')';
    q += ' ORDER BY created_at DESC LIMIT 1';

    const mr = await pool.query(q, params);
    if (mr.rows.length) matched = mr.rows[0];

    const ins = await pool.query(
      `INSERT INTO enquiries
        (asked_by, person_name, approx_age, gender, last_seen_date, last_seen_place,
         clothing, extra_desc, officer_name, officer_badge, officer_station, matched_case_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
      [user.id, person_name||null, approx_age||null, gender||null,
       last_seen_date, last_seen_place, clothing, extra_desc||null,
       'N/A', 'N/A', 'N/A',
       matched ? matched.id : null]
    );

    return res.status(201).json({
      enquiry: ins.rows[0],
      match: matched ? {
        found: true,
        case_number:        matched.case_number,
        mp_name:            matched.mp_name,
        mp_age:             matched.mp_age,
        mp_gender:          matched.mp_gender,
        last_seen_location: matched.last_seen_location,
        last_seen_date:     matched.last_seen_date,
        clothing:           matched.clothing,
        status:             matched.status,
        police_station:     matched.police_station,
        police_area:        matched.police_area,
        fir_number:         matched.fir_number,
        current_location:   matched.current_location || null,
        reporter_relation:  matched.reporter_relation,
      } : { found: false }
    });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Server error.' });
  }
}
