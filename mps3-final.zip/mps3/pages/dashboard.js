import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const u = localStorage.getItem('user');
    if (!localStorage.getItem('token')) { router.push('/'); return; }
    if (u) setUser(JSON.parse(u));
  }, []);

  function logout() { localStorage.clear(); router.push('/'); }
  if (!user) return null;

  return (
    <>
      <Head><title>Dashboard – MPS</title></Head>
      <nav className="nav">
        <span className="nav-brand">Missing Person System</span>
        <div className="nav-right">
          <span className="nav-user">{user.name}</span>
          <button className="nav-btn" onClick={logout}>Logout</button>
        </div>
      </nav>

      <div className="page-wide">
        <div className="card">
          <div className="page-title">Welcome, {user.name}</div>
          <div className="page-sub">Choose what you would like to do today.</div>

          <div className="options">
            <div className="opt-box" onClick={()=>router.push('/report')}>
              <div className="opt-icon">&#128203;</div>
              <div className="opt-title">Report a Missing Person</div>
              <div className="opt-desc">
                File a detailed report for a missing person — their personal details, physical description, last seen location and FIR information.
              </div>
              <button className="btn btn-blue btn-sm" style={{ marginTop:'16px' }}>Start Report</button>
            </div>

            <div className="opt-box" onClick={()=>router.push('/enquiry')}>
              <div className="opt-icon">&#128270;</div>
              <div className="opt-title">Enquiry About a Person</div>
              <div className="opt-desc">
                Search for a missing person by entering their description and last seen details. Police verification is required for all enquiries.
              </div>
              <button className="btn btn-blue btn-sm" style={{ marginTop:'16px' }}>Make Enquiry</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
