import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';

export default function EnquiryPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [err, setErr]         = useState('');
  const [result, setResult]   = useState(null);

  const [f, setF] = useState({
    person_name:'', approx_age:'', gender:'',
    last_seen_date:'', last_seen_place:'', clothing:'', extra_desc:'',
  });
  const s = (k,v) => setF(p=>({...p,[k]:v}));

  useEffect(() => { if (!localStorage.getItem('token')) router.push('/'); }, []);

  async function submit(e) {
    e.preventDefault(); setErr(''); setLoading(true);
    const token = localStorage.getItem('token');
    const res   = await fetch('/api/enquiries/submit', {
      method:'POST',
      headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`},
      body: JSON.stringify(f),
    });
    const data = await res.json(); setLoading(false);
    if (!res.ok) return setErr(data.error);
    setResult(data);
  }

  function statusBadge(s) {
    if (s==='found')  return <span className="badge badge-found">Found</span>;
    if (s==='closed') return <span className="badge badge-closed">Closed</span>;
    return <span className="badge badge-active">Active</span>;
  }

  // ── Result screen ─────────────────────────────────────────
  if (result) {
    const m = result.match;
    return (
      <>
        <Head><title>Enquiry Result – MPS</title></Head>
        <nav className="nav">
          <span className="nav-brand">Missing Person System</span>
          <button className="nav-btn" onClick={()=>router.push('/dashboard')}>Home</button>
        </nav>
        <div className="page">
          <div className="card">
            <div className="success-wrap">
              <div className="s-icon" style={{fontSize:'44px'}}>{m.found ? '✓' : '—'}</div>
              <div className="s-title" style={{color: m.found ? '#4ade80' : '#f59e0b'}}>
                {m.found ? 'Match Found in Database' : 'No Match Found'}
              </div>
              <p className="s-desc">
                {m.found
                  ? 'A matching missing person record was found. Details are shown below.'
                  : 'No matching record found right now. Your enquiry has been registered.'}
              </p>
            </div>

            {m.found && (
              <div className="match-card" style={{marginTop:'20px'}}>
                <h3>Matched Person Details</h3>
                <div className="drow"><span className="drow-label">Case Number</span><span className="drow-val" style={{fontFamily:'monospace'}}>{m.case_number}</span></div>
                <div className="drow"><span className="drow-label">Name</span><span className="drow-val">{m.mp_name}</span></div>
                <div className="drow"><span className="drow-label">Age / Gender</span><span className="drow-val">{m.mp_age} yrs / {m.mp_gender}</span></div>
                <div className="drow"><span className="drow-label">Last Seen</span><span className="drow-val">{m.last_seen_location}</span></div>
                <div className="drow"><span className="drow-label">Last Seen Date</span><span className="drow-val">{new Date(m.last_seen_date).toLocaleDateString('en-IN')}</span></div>
                <div className="drow"><span className="drow-label">Clothing</span><span className="drow-val">{m.clothing}</span></div>
                <div className="drow"><span className="drow-label">Case Status</span><span className="drow-val">{statusBadge(m.status)}</span></div>
                <div className="drow"><span className="drow-label">Reported By</span><span className="drow-val">{m.reporter_relation}</span></div>

                <div style={{marginTop:'16px', background:'#172554', border:'1px solid #1d4ed8', borderRadius:'8px', padding:'14px', fontSize:'13px', color:'#93c5fd', lineHeight:1.7}}>
                  <strong style={{display:'block', marginBottom:'6px', color:'#60a5fa'}}>Police Station Details</strong>
                  {m.police_station && <div>Station: <strong>{m.police_station}</strong></div>}
                  {m.police_area    && <div>Area / District: <strong>{m.police_area}</strong></div>}
                  {m.fir_number     && <div>FIR Number: <strong>{m.fir_number}</strong></div>}
                  {m.current_location && <div style={{marginTop:'6px'}}>Current Location: <strong>{m.current_location}</strong></div>}
                  {!m.police_station && <div>Contact your local police station with Case Number <strong>{m.case_number}</strong> for more details.</div>}
                </div>
              </div>
            )}

            {!m.found && (
              <div className="no-match-card" style={{marginTop:'20px'}}>
                <h3>Enquiry Registered</h3>
                <p>
                  Enquiry ID: <strong>#{result.enquiry.id}</strong><br /><br />
                  Your enquiry has been saved. If a matching report is filed in the future, you will be notified.
                  You can also contact your local police station for further updates.
                </p>
              </div>
            )}

            <button className="btn btn-blue btn-full" style={{marginTop:'20px'}} onClick={()=>router.push('/dashboard')}>
              Back to Dashboard
            </button>
          </div>
        </div>
      </>
    );
  }

  // ── Enquiry Form ──────────────────────────────────────────
  return (
    <>
      <Head><title>Enquiry – MPS</title></Head>
      <nav className="nav">
        <span className="nav-brand">Missing Person System</span>
        <button className="nav-btn" onClick={()=>router.push('/dashboard')}>Back</button>
      </nav>

      <div className="page" style={{maxWidth:'620px'}}>
        <div className="card">
          <div className="page-title">Enquiry About a Person</div>
          <div className="page-sub">Enter the details of the person you are searching for. We will search the database for a match.</div>

          {err && <div className="alert-err">{err}</div>}

          <form onSubmit={submit}>
            <div className="sec-label">Person Details</div>

            <div className="fgroup">
              <label>Person's Name (if known)</label>
              <input type="text" placeholder="Full or partial name"
                value={f.person_name} onChange={e=>s('person_name',e.target.value)} />
            </div>

            <div className="frow">
              <div className="fgroup">
                <label>Approximate Age</label>
                <input type="number" placeholder="Estimated age" min="0" max="120"
                  value={f.approx_age} onChange={e=>s('approx_age',e.target.value)} />
              </div>
              <div className="fgroup">
                <label>Gender</label>
                <select value={f.gender} onChange={e=>s('gender',e.target.value)}>
                  <option value="">Select</option>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
            </div>

            <div className="frow">
              <div className="fgroup">
                <label>Date Last Seen <span className="req">*</span></label>
                <input type="date" value={f.last_seen_date}
                  onChange={e=>s('last_seen_date',e.target.value)} required />
              </div>
              <div className="fgroup">
                <label>Place Last Seen <span className="req">*</span></label>
                <input type="text" placeholder="Area or city"
                  value={f.last_seen_place} onChange={e=>s('last_seen_place',e.target.value)} required />
              </div>
            </div>

            <div className="fgroup">
              <label>Clothing When Last Seen <span className="req">*</span></label>
              <textarea placeholder="Describe what they were wearing"
                value={f.clothing} onChange={e=>s('clothing',e.target.value)} required />
            </div>

            <div className="fgroup">
              <label>Any Other Description</label>
              <textarea placeholder="Height, complexion, marks, features, spectacles..."
                value={f.extra_desc} onChange={e=>s('extra_desc',e.target.value)} />
            </div>

            <button className="btn btn-blue btn-full" type="submit" disabled={loading}>
              {loading ? 'Searching...' : 'Search'}
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
