import { useState } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';

export default function Home() {
  const router = useRouter();
  const [mode, setMode]   = useState('login');
  const [role, setRole]   = useState('user');
  const [loading, setLoading] = useState(false);
  const [err, setErr]     = useState('');

  const [lf, setLf] = useState({ email:'', password:'' });
  const [rf, setRf] = useState({ name:'', email:'', phone:'', password:'', badge_number:'', station_name:'', station_area:'' });

  const sl = (k,v) => setLf(p=>({...p,[k]:v}));
  const sr = (k,v) => setRf(p=>({...p,[k]:v}));

  async function doLogin(e) {
    e.preventDefault(); setErr(''); setLoading(true);
    const res  = await fetch('/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(lf) });
    const data = await res.json(); setLoading(false);
    if (!res.ok) return setErr(data.error);
    localStorage.setItem('token', data.token);
    localStorage.setItem('user',  JSON.stringify(data.user));
    router.push(data.user.role === 'police' ? '/police' : '/dashboard');
  }

  async function doRegister(e) {
    e.preventDefault(); setErr(''); setLoading(true);
    const res  = await fetch('/api/auth/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({...rf, role}) });
    const data = await res.json(); setLoading(false);
    if (!res.ok) return setErr(data.error);
    localStorage.setItem('token', data.token);
    localStorage.setItem('user',  JSON.stringify(data.user));
    router.push(data.user.role === 'police' ? '/police' : '/dashboard');
  }

  return (
    <>
      <Head><title>Missing Person System</title></Head>
      <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'#0f172a', padding:'20px' }}>
        <div style={{ width:'100%', maxWidth:'440px' }}>

          {/* Header */}
          <div style={{ textAlign:'center', marginBottom:'28px' }}>
            <div style={{ width:'56px', height:'56px', background:'#3b82f6', borderRadius:'12px', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px', color:'#fff', fontSize:'26px' }}>
              &#128269;
            </div>
            <h1 style={{ fontSize:'22px', fontWeight:700, color:'#f1f5f9' }}>Missing Person System</h1>
            <p style={{ fontSize:'13px', color:'#475569', marginTop:'5px' }}>Report or search for missing persons</p>
          </div>

          <div className="card">
            {/* Mode tabs */}
            <div className="tabs">
              <button className={`tab ${mode==='login'?'active':''}`}    onClick={()=>{setMode('login');   setErr('');}}>Login</button>
              <button className={`tab ${mode==='register'?'active':''}`} onClick={()=>{setMode('register');setErr('');}}>Register</button>
            </div>

            {/* Role selector */}
            <div style={{ display:'flex', gap:'10px', marginBottom:'20px' }}>
              {['user','police'].map(r=>(
                <button key={r} onClick={()=>setRole(r)}
                  style={{
                    flex:1, padding:'10px',
                    border: `2px solid ${role===r?'#3b82f6':'#334155'}`,
                    borderRadius:'7px',
                    background: role===r ? '#172554' : '#0f172a',
                    color: role===r ? '#60a5fa' : '#475569',
                    fontWeight: role===r ? 700 : 500,
                    cursor:'pointer', fontFamily:'inherit', fontSize:'14px',
                    transition:'all .15s'
                  }}>
                  {r==='user' ? 'General User' : 'Police Officer'}
                </button>
              ))}
            </div>

            {err && <div className="alert-err">{err}</div>}

            {/* LOGIN */}
            {mode==='login' && (
              <form onSubmit={doLogin}>
                <div className="fgroup">
                  <label>Email Address</label>
                  <input type="email" placeholder="Enter your email" value={lf.email} onChange={e=>sl('email',e.target.value)} required />
                </div>
                <div className="fgroup">
                  <label>Password</label>
                  <input type="password" placeholder="Enter your password" value={lf.password} onChange={e=>sl('password',e.target.value)} required />
                </div>
                <button className="btn btn-blue btn-full" disabled={loading}>{loading?'Logging in...':'Login'}</button>
                <p style={{ textAlign:'center', marginTop:'14px', fontSize:'13px', color:'#475569' }}>
                  No account? <button className="lbtn" type="button" onClick={()=>setMode('register')}>Register here</button>
                </p>
              </form>
            )}

            {/* REGISTER */}
            {mode==='register' && (
              <form onSubmit={doRegister}>
                <div className="fgroup">
                  <label>Full Name <span className="req">*</span></label>
                  <input type="text" placeholder="Your full name" value={rf.name} onChange={e=>sr('name',e.target.value)} required />
                </div>
                <div className="frow">
                  <div className="fgroup">
                    <label>Email <span className="req">*</span></label>
                    <input type="email" placeholder="Email address" value={rf.email} onChange={e=>sr('email',e.target.value)} required />
                  </div>
                  <div className="fgroup">
                    <label>Phone <span className="req">*</span></label>
                    <input type="tel" placeholder="Phone number" value={rf.phone} onChange={e=>sr('phone',e.target.value)} required />
                  </div>
                </div>
                <div className="fgroup">
                  <label>Password <span className="req">*</span></label>
                  <input type="password" placeholder="At least 6 characters" value={rf.password} onChange={e=>sr('password',e.target.value)} required />
                </div>

                {role==='police' && (
                  <>
                    <div className="police-info-box">
                      Police officer details are required and will be verified by the admin.
                    </div>
                    <div className="frow">
                      <div className="fgroup">
                        <label>Badge Number <span className="req">*</span></label>
                        <input type="text" placeholder="e.g. UK-1234" value={rf.badge_number} onChange={e=>sr('badge_number',e.target.value)} required />
                      </div>
                      <div className="fgroup">
                        <label>Station Name <span className="req">*</span></label>
                        <input type="text" placeholder="Station name" value={rf.station_name} onChange={e=>sr('station_name',e.target.value)} required />
                      </div>
                    </div>
                    <div className="fgroup">
                      <label>Station Area / District <span className="req">*</span></label>
                      <input type="text" placeholder="e.g. Dehradun, Rajpur Road area" value={rf.station_area} onChange={e=>sr('station_area',e.target.value)} required />
                    </div>
                  </>
                )}

                <button className="btn btn-blue btn-full" disabled={loading}>{loading?'Creating account...':'Create Account'}</button>
                <p style={{ textAlign:'center', marginTop:'14px', fontSize:'13px', color:'#475569' }}>
                  Already registered? <button className="lbtn" type="button" onClick={()=>setMode('login')}>Login here</button>
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
