import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';

export default function PoliceDashboard() {
  const router = useRouter();
  const [user, setUser]   = useState(null);
  const [data, setData]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr]     = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    const u     = localStorage.getItem('user');
    if (!token) { router.push('/'); return; }
    const parsed = JSON.parse(u || '{}');
    if (parsed.role !== 'police') { router.push('/dashboard'); return; }
    setUser(parsed);
    fetchData(token);
  }, []);

  async function fetchData(token) {
    setLoading(true);
    const res  = await fetch('/api/cases/police-dashboard', { headers:{ Authorization:`Bearer ${token}` } });
    const json = await res.json();
    setLoading(false);
    if (!res.ok) { setErr(json.error); return; }
    setData(json);
  }

  function logout() { localStorage.clear(); router.push('/'); }

  function statusBadge(s) {
    if (s==='found')  return <span className="badge badge-found">Found</span>;
    if (s==='closed') return <span className="badge badge-closed">Closed</span>;
    return <span className="badge badge-active">Active</span>;
  }

  return (
    <>
      <Head><title>Police Dashboard – MPS</title></Head>
      <nav className="nav">
        <span className="nav-brand">Missing Person System — Police Portal</span>
        <div className="nav-right">
          {user && <span className="nav-user">{user.name} &nbsp;|&nbsp; {user.station_name}</span>}
          <button className="nav-btn" onClick={logout}>Logout</button>
        </div>
      </nav>

      <div className="page-wide">
        {loading && (
          <div className="card" style={{ textAlign:'center', color:'#475569', padding:'48px' }}>
            Loading dashboard...
          </div>
        )}
        {err && <div className="alert-err">{err}</div>}

        {data && (
          <>
            {/* Station info */}
            <div className="card" style={{ marginBottom:'20px' }}>
              <div className="page-title">{data.station_name}</div>
              <div className="page-sub">Area / District: {data.station_area}</div>
            </div>

            {/* Stats */}
            <div className="stat-grid">
              <div className="stat-box blue">
                <div className="stat-num">{data.stats.total}</div>
                <div className="stat-label">Total Cases</div>
              </div>
              <div className="stat-box yellow">
                <div className="stat-num">{data.stats.active}</div>
                <div className="stat-label">Active / Pending</div>
              </div>
              <div className="stat-box green">
                <div className="stat-num">{data.stats.found}</div>
                <div className="stat-label">Found</div>
              </div>
              <div className="stat-box gray">
                <div className="stat-num">{data.stats.closed}</div>
                <div className="stat-label">Closed</div>
              </div>
            </div>

            {/* Cases table */}
            <div className="card">
              <div className="page-title" style={{ marginBottom:'16px' }}>Recent Cases in Your Area</div>
              {data.recent_cases.length === 0 ? (
                <p style={{ color:'#475569', fontSize:'14px', textAlign:'center', padding:'24px 0' }}>
                  No cases registered in your area yet.
                </p>
              ) : (
                <div style={{ overflowX:'auto' }}>
                  <table className="cases-table">
                    <thead>
                      <tr>
                        <th>Case No.</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Last Seen</th>
                        <th>Date</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.recent_cases.map(c=>(
                        <tr key={c.id}>
                          <td style={{ fontFamily:'monospace', fontWeight:600, color:'#60a5fa' }}>{c.case_number}</td>
                          <td style={{ fontWeight:500, color:'#f1f5f9' }}>{c.mp_name}</td>
                          <td>{c.mp_age}</td>
                          <td>{c.mp_gender}</td>
                          <td style={{ maxWidth:'160px', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{c.last_seen_location}</td>
                          <td>{new Date(c.last_seen_date).toLocaleDateString('en-IN')}</td>
                          <td>{statusBadge(c.status)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Note */}
            <div className="station-info-box" style={{ marginTop:'16px' }}>
              <strong style={{ color:'#93c5fd' }}>Note:</strong> Cases appear here when a reporter enters your station area while filing a report.
              Currently filtering by area: <strong>{data.station_area}</strong>
            </div>
          </>
        )}
      </div>
    </>
  );
}
