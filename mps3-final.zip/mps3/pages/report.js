import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';

const RELATIONS = ['Parent','Child','Spouse / Partner','Sibling','Grandparent',
                   'Relative','Friend','Neighbour','Employer','Guardian','Other'];

export default function ReportPage() {
  const router = useRouter();
  const [step, setStep]       = useState(1);
  const [relation, setRel]    = useState('');
  const [loading, setLoading] = useState(false);
  const [err, setErr]         = useState('');
  const [done, setDone]       = useState(false);
  const [caseData, setCaseData] = useState(null);

  const [f, setF] = useState({
    reporter_name:'', reporter_phone:'', reporter_email:'',
    mp_name:'', mp_age:'', mp_gender:'', mp_dob:'', mp_nationality:'Indian',
    mp_height_cm:'', mp_weight_kg:'', mp_hair:'', mp_eyes:'', mp_marks:'',
    last_seen_date:'', last_seen_time:'', last_seen_location:'',
    clothing:'', clothing_color:'', photo_url:'',
    fir_number:'', police_station:'', police_area:'',
  });

  const s = (k,v) => setF(p=>({...p,[k]:v}));

  useEffect(() => { if (!localStorage.getItem('token')) router.push('/'); }, []);

  async function submit(e) {
    e.preventDefault(); setErr(''); setLoading(true);
    const token = localStorage.getItem('token');
    const res   = await fetch('/api/cases/report', {
      method:'POST',
      headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`},
      body: JSON.stringify({ ...f, reporter_relation: relation }),
    });
    const data = await res.json(); setLoading(false);
    if (!res.ok) return setErr(data.error);
    setCaseData(data.data); setDone(true);
  }

  // ── Success ──────────────────────────────────────────────
  if (done && caseData) return (
    <>
      <Head><title>Report Submitted – MPS</title></Head>
      <nav className="nav">
        <span className="nav-brand">Missing Person System</span>
        <button className="nav-btn" onClick={()=>router.push('/dashboard')}>Home</button>
      </nav>
      <div className="page">
        <div className="card">
          <div className="success-wrap">
            <div className="s-icon">&#10003;</div>
            <div className="s-title">Report Submitted Successfully</div>
            <p className="s-desc">The missing person report has been registered in the system.</p>
            <div className="case-box">
              <div className="case-num">{caseData.case_number}</div>
              <div className="case-hint">Save this Case Number for all future reference</div>
            </div>
          </div>
          <div className="drow"><span className="drow-label">Name</span><span className="drow-val">{caseData.mp_name}</span></div>
          <div className="drow"><span className="drow-label">Age / Gender</span><span className="drow-val">{caseData.mp_age} yrs / {caseData.mp_gender}</span></div>
          <div className="drow"><span className="drow-label">Last Seen</span><span className="drow-val">{caseData.last_seen_location}</span></div>
          <div className="drow"><span className="drow-label">Status</span><span className="drow-val"><span className="badge badge-active">Active</span></span></div>
          <button className="btn btn-blue btn-full" style={{marginTop:'20px'}} onClick={()=>router.push('/dashboard')}>Back to Dashboard</button>
        </div>
      </div>
    </>
  );

  return (
    <>
      <Head><title>Report Missing Person – MPS</title></Head>
      <nav className="nav">
        <span className="nav-brand">Missing Person System</span>
        <button className="nav-btn" onClick={()=>step===2?setStep(1):router.push('/dashboard')}>
          {step===2 ? 'Back' : 'Home'}
        </button>
      </nav>

      <div className="page" style={{maxWidth:'660px'}}>
        <div className="card">

          {/* Step bar */}
          <div className="stepbar">
            <div className={`s-item ${step>=1?(step>1?'done':'active'):''}`}>
              <div className="s-circle">{step>1?'✓':'1'}</div> Your Details
            </div>
            <div className={`s-line ${step>1?'done':''}`} />
            <div className={`s-item ${step>=2?'active':''}`}>
              <div className="s-circle">2</div> Missing Person Details
            </div>
          </div>

          {/* ── STEP 1 ─────────────────────────────── */}
          {step===1 && (
            <>
              <div className="page-title">Report a Missing Person</div>
              <div className="page-sub">First, enter your contact details and relationship to the missing person.</div>
              {err && <div className="alert-err">{err}</div>}

              <div className="sec-label">Your Information</div>
              <div className="frow">
                <div className="fgroup">
                  <label>Your Full Name <span className="req">*</span></label>
                  <input type="text" placeholder="Your name" value={f.reporter_name} onChange={e=>s('reporter_name',e.target.value)} />
                </div>
                <div className="fgroup">
                  <label>Your Phone <span className="req">*</span></label>
                  <input type="tel" placeholder="Mobile number" value={f.reporter_phone} onChange={e=>s('reporter_phone',e.target.value)} />
                </div>
              </div>
              <div className="fgroup">
                <label>Your Email</label>
                <input type="email" placeholder="Optional" value={f.reporter_email} onChange={e=>s('reporter_email',e.target.value)} />
              </div>

              <div className="sec-label">Your Relation to the Missing Person <span className="req">*</span></div>
              <div className="rel-grid">
                {RELATIONS.map(r=>(
                  <div key={r} className={`rel-item ${relation===r?'selected':''}`} onClick={()=>setRel(r)}>
                    <span className="rel-dot">{relation===r?'●':'○'}</span> {r}
                  </div>
                ))}
              </div>

              <button className="btn btn-blue btn-full" style={{marginTop:'16px'}}
                disabled={!relation || !f.reporter_name || !f.reporter_phone}
                onClick={()=>{ if(!f.reporter_name||!f.reporter_phone){setErr('Please fill your name and phone.'); return;} setErr(''); setStep(2); }}>
                Continue to Person Details
              </button>
            </>
          )}

          {/* ── STEP 2 ─────────────────────────────── */}
          {step===2 && (
            <>
              <div className="page-title">Missing Person Details</div>
              <div className="page-sub">Reporting as: <strong style={{color:'#1e40af'}}>{relation}</strong></div>
              {err && <div className="alert-err">{err}</div>}

              <form onSubmit={submit}>
                <div className="sec-label">Personal Information</div>
                <div className="fgroup">
                  <label>Full Name <span className="req">*</span></label>
                  <input type="text" placeholder="Full legal name" value={f.mp_name} onChange={e=>s('mp_name',e.target.value)} required />
                </div>
                <div className="frow">
                  <div className="fgroup">
                    <label>Age <span className="req">*</span></label>
                    <input type="number" placeholder="Age" min="0" max="120" value={f.mp_age} onChange={e=>s('mp_age',e.target.value)} required />
                  </div>
                  <div className="fgroup">
                    <label>Gender <span className="req">*</span></label>
                    <select value={f.mp_gender} onChange={e=>s('mp_gender',e.target.value)} required>
                      <option value="">Select</option>
                      <option>Male</option><option>Female</option><option>Other</option>
                    </select>
                  </div>
                  <div className="fgroup">
                    <label>Date of Birth</label>
                    <input type="date" value={f.mp_dob} onChange={e=>s('mp_dob',e.target.value)} />
                  </div>
                </div>
                <div className="frow">
                  <div className="fgroup">
                    <label>Nationality</label>
                    <input type="text" value={f.mp_nationality} onChange={e=>s('mp_nationality',e.target.value)} />
                  </div>
                </div>

                <div className="sec-label">Physical Description</div>
                <div className="frow">
                  <div className="fgroup">
                    <label>Height (cm)</label>
                    <input type="number" placeholder="e.g. 165" value={f.mp_height_cm} onChange={e=>s('mp_height_cm',e.target.value)} />
                  </div>
                  <div className="fgroup">
                    <label>Weight (kg)</label>
                    <input type="number" placeholder="e.g. 60" value={f.mp_weight_kg} onChange={e=>s('mp_weight_kg',e.target.value)} />
                  </div>
                </div>
                <div className="frow">
                  <div className="fgroup">
                    <label>Hair</label>
                    <input type="text" placeholder="Color and style" value={f.mp_hair} onChange={e=>s('mp_hair',e.target.value)} />
                  </div>
                  <div className="fgroup">
                    <label>Eyes</label>
                    <input type="text" placeholder="Eye color" value={f.mp_eyes} onChange={e=>s('mp_eyes',e.target.value)} />
                  </div>
                </div>
                <div className="fgroup">
                  <label>Distinguishing Marks</label>
                  <textarea placeholder="Birthmarks, tattoos, scars, spectacles, disability..." value={f.mp_marks} onChange={e=>s('mp_marks',e.target.value)} />
                </div>

                <div className="sec-label">Last Seen Information</div>
                <div className="frow">
                  <div className="fgroup">
                    <label>Date Last Seen <span className="req">*</span></label>
                    <input type="date" value={f.last_seen_date} onChange={e=>s('last_seen_date',e.target.value)} required />
                  </div>
                  <div className="fgroup">
                    <label>Time Last Seen</label>
                    <input type="time" value={f.last_seen_time} onChange={e=>s('last_seen_time',e.target.value)} />
                  </div>
                </div>
                <div className="fgroup">
                  <label>Last Seen Location <span className="req">*</span></label>
                  <textarea placeholder="Full address or area — street, locality, city, state" value={f.last_seen_location} onChange={e=>s('last_seen_location',e.target.value)} required />
                </div>
                <div className="fgroup">
                  <label>Clothing Description <span className="req">*</span></label>
                  <textarea placeholder="Describe all clothing — shirt, pants, shoes, saree, etc." value={f.clothing} onChange={e=>s('clothing',e.target.value)} required />
                </div>
                <div className="fgroup">
                  <label>Clothing Colors</label>
                  <input type="text" placeholder="e.g. Blue shirt, black trousers, brown sandals" value={f.clothing_color} onChange={e=>s('clothing_color',e.target.value)} />
                </div>

                <div className="sec-label">FIR / Police Station Details</div>
                <div className="frow">
                  <div className="fgroup">
                    <label>FIR Number</label>
                    <input type="text" placeholder="e.g. 123/2024" value={f.fir_number} onChange={e=>s('fir_number',e.target.value)} />
                  </div>
                  <div className="fgroup">
                    <label>Police Station</label>
                    <input type="text" placeholder="Station name" value={f.police_station} onChange={e=>s('police_station',e.target.value)} />
                  </div>
                </div>
                <div className="fgroup">
                  <label>Police Station Area / District</label>
                  <input type="text" placeholder="e.g. Dehradun, Rajpur Road" value={f.police_area} onChange={e=>s('police_area',e.target.value)} />
                </div>
                <div className="fgroup">
                  <label>Photo URL</label>
                  <input type="url" placeholder="Link to a photo (optional)" value={f.photo_url} onChange={e=>s('photo_url',e.target.value)} />
                </div>

                <button className="btn btn-blue btn-full" type="submit" disabled={loading}>
                  {loading ? 'Submitting...' : 'Submit Report'}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </>
  );
}
